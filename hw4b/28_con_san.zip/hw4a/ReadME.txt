HW4A created by Nicole Contreras and Nikolas Sanderson 4/4/2024

This runs the part a required for the assignment where it prints out the board, the conflict vectors for each column, row, and square, and if the board is solved

To run the make file run make. 
If the make file fails run: g++ hw4a.cpp -o output
Then run .\output to run