HW4B created by Nicole Contreras and Nikolas Sanderson 4/4/2024

This program runs a recursive algorithm to solve the sudoku board. 
This runs for each of the 97 boards in the sudoku.txt file.
It prints out the unsolved board, the solved board, the recursive calls required for this specifc board,
the total recursive calls, and the avgerage calls for the boards.

To run the make file run make. 
If the make file fails run: g++ hw4b.cpp -o output
Then run .\output to run